import math

class Data:
    def __init__(self, feature, classification):
        self.classification = classification
        self.features = feature


def prior(objects, selectedClass):
    className = [object.classification for object in objects]
    return className.count(selectedClass)/len(objects)


def likelihood(objects, selectedClass, values):
    likely = 1
    classCount = [object.classification for object in objects].count(selectedClass)

    for i in range(0, len(values)):
        count = 0
        for object in objects:
            if object.classification == selectedClass and object.features[i] == values[i]:
                count += 1

        likely *= (count / classCount)

    return likely


def mean(data):
    return sum(data) / len(data)


def variance(data):
    m = mean(data)
    return sum((xi - m) ** 2 for xi in data) / (len(data)-1)


def numericLikelihood(objects, selectedClass, values):
    likely = 1
    # classCount = [object.classification for object in objects].count(selectedClass)
    filteredObjects = [object for object in objects if object.classification == selectedClass]

    for i in range(0, len(values)):
        var = variance([object.numericFeatures[i] for object in filteredObjects])
        m = mean([object.numericFeatures[i] for object in filteredObjects])

        likely *= (1 / ((2 * math.pi * var) ** 0.5) * math.exp(-((values[i] - m) ** 2 / (2 * var))))

    return likely


def posterior(objects, selectedClass, values):
    return likelihood(objects, selectedClass, values) * prior(objects, selectedClass)


def decision(objects, values):
    classes = set([object.classification for object in objects])
    classes = list(classes)
    results = []
    for className in classes:
        results.append(posterior(objects, className, values))
    print(classes)
    print(results)
    return classes[results.index(max(results))]


source = open("e:/UB/Semester 5/Pengenalan Pola/Project/data.txt", "r")
source = source.read()
data = source.split('\n')
for i in range(len(data)):
    data[i] = data[i].split(',')

for i in range(len(data)):
    data[i] = Data([data[i][0], data[i][1], data[i][2], data[i][3], data[i][4], data[i][5]], data[i][6])
print(decision(data, ['vhigh', 'vhigh', '5more', 'more', 'small', 'med']))
                    # buying, maintenance, doors, persons, lugage, safety
